package lk.ijse.dep;

public class Launcher {

    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
